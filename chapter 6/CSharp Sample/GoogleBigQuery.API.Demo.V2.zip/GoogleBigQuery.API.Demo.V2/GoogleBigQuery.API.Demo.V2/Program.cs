﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Bigquery.v2.Data;
using Google.Cloud.BigQuery.V2;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace GoogleBigQuery.API.Demo.V2
{
    class Program
    {
        //This is the Google Cloud project id not the name.
        const string GCPProjectID = "my-first-project-170319";
        //This is the schema to for the demo table to be created.
        const string TableSchemaDefinition = "EmployeeID:INTEGER,FirstName:STRING,LastName:STRING,JoiningDate:DATE,Employeelocation:STRING";
        //This is the file from which the data will be loaded to the table.
        const string LoadFilePath = "gs://myfirstprojectbucket201706/employeedetails.csv";

        static void Main(string[] args)
        {
            //create an instance of BigQuery service client for the project from the 
            //service account credential json file.
            //use app.config file to store the path of the json file for the application to read.
            BigQueryClient bqClient = BigQueryClient.Create(GCPProjectID, 
                                      GoogleCredential.FromStream(new StreamReader(@"C:\Temp\ProdProject.json").BaseStream)
                                      );

            //Display all the datasets and the tables in the project.
            ListAllDatasetsAndTableInProject(bqClient);

            //Create a new dataset if it does not exists.
            string newDatasetName = string.Format("SampleDataset_{0:yyyyMM}", DateTime.Today);
            var sampleDataset = CreateNewDataset(bqClient, newDatasetName);

            //Create a new table if it does not exists.
            string newTableName = "EmployeeDetails";
            var employeeTable = CreateNewTable(bqClient, newDatasetName, newTableName, "Employees list");

            //Load data from table
            LoadDataFromFileToTable(bqClient, employeeTable);

            //Query the table and display the results.
            ExecuteQueryAndDisplayResults(bqClient, sampleDataset, employeeTable);

            //Copy rows from query to a new table.
            ExecuteQueryAndCopyRows(bqClient, sampleDataset, employeeTable, "EmployeeDetails_Copy");

            //Streaming insert - insert rows dynamically.
            InsertRowsViaAPI(bqClient, sampleDataset, employeeTable);

            Console.ReadLine();
        }

        private static void InsertRowsViaAPI(BigQueryClient bqClient, BigQueryDataset sampleDataset, BigQueryTable employeeTable)
        {
            List<BigQueryInsertRow> lstRowsToInsert = new List<BigQueryInsertRow>();

            Dictionary<string, object> columnValues = new Dictionary<string, object>();

            BigQueryInsertRow bqRow1 = new BigQueryInsertRow();
            columnValues.Add("EmployeeID", 21);
            columnValues.Add("FirstName","Jeffery");
            columnValues.Add("LastName","Sng");
            columnValues.Add("JoiningDate", "2017-08-01");
            columnValues.Add("Employeelocation", "Singapore");
            bqRow1.Add(columnValues);
            lstRowsToInsert.Add(bqRow1);

            //Clear dictionary to add values for new row.
            columnValues.Clear();

            BigQueryInsertRow bqRow2 = new BigQueryInsertRow();
            columnValues.Add("EmployeeID", 21);
            columnValues.Add("FirstName", "Jeffery");
            columnValues.Add("LastName", "Sng");
            columnValues.Add("JoiningDate", "2017-08-01");
            columnValues.Add("Employeelocation", "Singapore");
            bqRow2.Add(columnValues);
            lstRowsToInsert.Add(bqRow2);

            bqClient.InsertRows(employeeTable.Reference, lstRowsToInsert);
        }

        private static void ExecuteQueryAndDisplayResults(BigQueryClient bqClient, BigQueryDataset sampleDataset, BigQueryTable sampleTable)
        {
            BigQueryCommand bqCommand = new BigQueryCommand();
            bqCommand.Sql = string.Format("SELECT * FROM `{0}.{1}` WHERE EmployeeID BETWEEN @MinEmployeeID and @MaxEmployeeID"
                , sampleDataset.Reference.DatasetId
                , sampleTable.Reference.TableId);
            bqCommand.Parameters.Add("MinEmployeeID", BigQueryDbType.Int64, 1);
            bqCommand.Parameters.Add("MaxEmployeeID", BigQueryDbType.Int64, 5);
            bqCommand.ParameterMode = BigQueryParameterMode.Named;

            var bqQueryJob = bqClient.CreateQueryJob(bqCommand, new QueryOptions() { UseLegacySql = false });
            bqQueryJob.PollUntilCompleted();

            var bqJobResult = bqQueryJob.GetQueryResults(new GetQueryResultsOptions() { StartIndex = 1, PageSize = 10, Timeout = new TimeSpan(0, 0, 10) });
            Console.WriteLine("Schema for the rows returned: " + JsonConvert.SerializeObject(bqJobResult.Schema.Fields));
            foreach (var record in bqJobResult)
            {
                Console.WriteLine("------------------------------------------------------------------------");
                foreach (var column in record.RawRow.F)
                {
                    Console.WriteLine(column.V.ToString());
                }
                Console.WriteLine("------------------------------------------------------------------------");
            }
        }

        private static void ExecuteQueryAndCopyRows(BigQueryClient bqClient, BigQueryDataset sourceDataset, BigQueryTable sourceTable, string destinationTableName)
        {
            BigQueryCommand bqCommand = new BigQueryCommand();
            bqCommand.Sql = string.Format("SELECT * FROM `{0}.{1}` WHERE EmployeeID BETWEEN @MinEmployeeID and @MaxEmployeeID"
                , sourceDataset.Reference.DatasetId
                , sourceTable.Reference.TableId);
            bqCommand.Parameters.Add("MinEmployeeID", BigQueryDbType.Int64, 1);
            bqCommand.Parameters.Add("MaxEmployeeID", BigQueryDbType.Int64, 5);
            bqCommand.ParameterMode = BigQueryParameterMode.Named;

            QueryOptions bqQueryOptions = new QueryOptions();
            bqQueryOptions.AllowLargeResults = true;
            bqQueryOptions.CreateDisposition = CreateDisposition.CreateIfNeeded;
            bqQueryOptions.DefaultDataset = sourceDataset.Reference;
            bqQueryOptions.DestinationTable = new TableReference() { ProjectId = bqClient.ProjectId, DatasetId = sourceDataset.Reference.DatasetId, TableId = destinationTableName };
            bqQueryOptions.UseLegacySql = false;
            bqQueryOptions.UseQueryCache = true;

            var bqQueryJob = bqClient.CreateQueryJob(bqCommand, bqQueryOptions);
            bqQueryJob.PollUntilCompleted();
        }

        private static void LoadDataFromFileToTable(BigQueryClient bqClient, BigQueryTable tableDetails)
        {
            //Load the data into the table from the file in Google Cloud Storage.
            var bqLoadJob = bqClient.CreateLoadJob(LoadFilePath, tableDetails.Reference, null
                , new CreateLoadJobOptions()
                {
                    SkipLeadingRows = 1,
                    WriteDisposition = WriteDisposition.WriteAppend //Other values - WriteTruncate to replace data. WriteIfEmpty to write only if the table is empty.
                });

            BigQueryJob bqJobStatus = bqClient.GetJob(bqLoadJob.Reference.JobId);

            //Wait on this thread until the job is complete.
            //Async option is also available via PollUntilCompletedAsync method.
            bqJobStatus = bqJobStatus.PollUntilCompleted();

            //Display the job status and statistics
            Console.WriteLine("Load job status");
            Console.WriteLine(JsonConvert.SerializeObject(bqJobStatus.Status));
            Console.WriteLine("Load job statistics");
            Console.WriteLine(JsonConvert.SerializeObject(bqJobStatus.Statistics));
        }

        private static void ListAllDatasetsAndTableInProject(BigQueryClient bqClient)
        {
            //Get the list of datasets and tables in the dataset in the project
            //Use ListDatasetsOption to filter dataset by wildcard chars in the name
            var datasetsList = bqClient.ListDatasets(GCPProjectID, new ListDatasetsOptions() { IncludeHidden = true });
            foreach (var datasetDetails in datasetsList)
            {
                Console.WriteLine("--------------------------------------------------------");
                Console.WriteLine("Dataset ID: " + datasetDetails.FullyQualifiedId);
                Console.WriteLine("Listing tables in the dataset " + datasetDetails.FullyQualifiedId);
                foreach (var tableDetails in datasetDetails.ListTables())
                {
                    Console.WriteLine("Table name: " + tableDetails.FullyQualifiedId);
                }
                Console.WriteLine("--------------------------------------------------------");
            }
        }

        private static BigQueryDataset CreateNewDataset(BigQueryClient bqClient, string newDatasetName)
        {
            //Get the list of datasets and tables in the dataset in the project
            //Use ListDatasetsOption to filter dataset by wildcard chars in the name
            var datasetsList = bqClient.ListDatasets(GCPProjectID, new ListDatasetsOptions() { IncludeHidden = true });

            //Create a dataset and create a table in it.
            //Use CreateDatasetOptions to specify expiration, friendly name, description and location for the dataset.
            if (!datasetsList.Any(ds => ds.Reference.DatasetId == newDatasetName))
            {
                Console.WriteLine("Creating the specified dataset");
                var newDataset = bqClient.CreateDataset(newDatasetName
                                     , new CreateDatasetOptions()
                                     {
                                         FriendlyName = "Current Month dataset",
                                         Description = "Store current month data for all tables here.",
                                         Location = "US"
                                     });
                Console.WriteLine("New dataset created successfully");
                return newDataset;
            }
            else
            {
                Console.WriteLine("Dataset already exists");
                return datasetsList.FirstOrDefault(ds => ds.Reference.DatasetId == newDatasetName);
            }
        }

        private static BigQueryTable CreateNewTable(BigQueryClient bqClient, string newDatasetName, string newTableName, string tableDescription)
        {
            TableSchema tableColumns = new TableSchema();
            tableColumns.Fields = new List<TableFieldSchema>();
            foreach (var fieldDetails in TableSchemaDefinition.Split(','))
            {
                var columnDetails = fieldDetails.Split(':');
                tableColumns.Fields.Add(new TableFieldSchema() { Name = columnDetails[0], Type = columnDetails[1] });
            }

            if (!bqClient.GetDataset(newDatasetName).ListTables().Any(table => table.Reference.TableId == newTableName))
            {
                Console.WriteLine("Creating new table in the specified dataset");
                
                var newTable = bqClient.CreateTable(newDatasetName, newTableName, new TableSchema() { Fields = tableColumns.Fields }
                                , new CreateTableOptions()
                                {
                                    Description = tableDescription
                                });
                Console.WriteLine("New table created successfully");
                return newTable;
            }
            else
            {
                Console.WriteLine("Table already exists");
                return bqClient.GetDataset(newDatasetName).ListTables().FirstOrDefault(table => table.Reference.TableId == newTableName);
            }
        }
    }
}
